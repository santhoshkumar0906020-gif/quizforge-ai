@echo off
title QuizForge AI Launcher
echo ========================================================
echo        Starting QuizForge AI EdTech Platform
echo ========================================================
echo.
cd /d "%~dp0"
python -m streamlit run quizforge_app.py --server.address 0.0.0.0 --server.port 8501
pause
