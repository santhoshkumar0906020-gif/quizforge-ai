import json
import os
import random
import re
from collections import Counter
from datetime import datetime

import streamlit as st

# ==============================================================================
# QuizForge AI — Multi-Role EdTech Portal
# Pre-Login Showcase · Student Dashboard · Teacher Studio · Class Analytics
# ==============================================================================

st.set_page_config(
    page_title="QuizForge AI — Student & Teacher Portal",
    page_icon="✦",
    layout="wide",
    initial_sidebar_state="collapsed"
)

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data_store.json")
MAX_NOTES_CHARS = 35000

# ==============================================================================
# DESIGN SYSTEM & CSS
# ==============================================================================
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Space+Grotesk:wght@500;600;700;800&display=swap');

:root {
  --bg: #090d1a;
  --card: rgba(18, 25, 46, 0.78);
  --card-solid: #111a33;
  --card-hover: #172344;
  --line: rgba(125, 145, 195, 0.22);
  --text: #f3f6ff;
  --muted: #95a3c6;
  --violet: #8b5cf6;
  --indigo: #5b6cff;
  --teal: #34e0d0;
  --amber: #f59e0b;
  --good: #2ee59d;
  --bad: #ff5d73;
  --radius: 18px;
}

html, body, [class*="css"] {
  font-family: 'Inter', sans-serif;
  color: var(--text);
}

#MainMenu, footer, header[data-testid="stHeader"] {
  visibility: hidden;
  height: 0;
}

.stApp {
  background:
    radial-gradient(1000px 550px at 8% -5%, rgba(139, 92, 246, 0.28), transparent 60%),
    radial-gradient(900px 550px at 98% 10%, rgba(52, 224, 208, 0.16), transparent 55%),
    radial-gradient(800px 500px at 50% 115%, rgba(91, 108, 255, 0.20), transparent 60%),
    var(--bg);
  color: var(--text);
}

.block-container {
  max-width: 1240px;
  padding-top: 1.2rem;
  padding-bottom: 3.5rem;
}

/* NAVBAR */
.nav-wrap {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 0 16px;
  border-bottom: 1px solid var(--line);
  margin-bottom: 22px;
}
.brand-group {
  display: flex;
  align-items: center;
  gap: 12px;
}
.brand-logo {
  width: 44px;
  height: 44px;
  border-radius: 13px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 22px;
  background: linear-gradient(135deg, var(--violet), var(--indigo));
  box-shadow: 0 8px 24px rgba(139, 92, 246, 0.42);
}
.brand-title {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 24px;
  font-weight: 800;
  letter-spacing: -0.4px;
}
.grad-text {
  background: linear-gradient(90deg, #c4b0ff, var(--teal));
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.user-pill {
  display: flex;
  align-items: center;
  gap: 10px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--line);
  padding: 6px 14px;
  border-radius: 999px;
  font-size: 13px;
}
.role-badge {
  font-size: 11px;
  font-weight: 800;
  text-transform: uppercase;
  letter-spacing: 1px;
  padding: 4px 10px;
  border-radius: 999px;
}
.badge-student {
  background: rgba(52, 224, 208, 0.16);
  color: var(--teal);
  border: 1px solid rgba(52, 224, 208, 0.35);
}
.badge-teacher {
  background: rgba(139, 92, 246, 0.18);
  color: #cdbfff;
  border: 1px solid rgba(139, 92, 246, 0.4);
}
.badge-guest {
  background: rgba(245, 158, 11, 0.16);
  color: var(--amber);
  border: 1px solid rgba(245, 158, 11, 0.35);
}

/* HERO SECTION */
.hero {
  position: relative;
  overflow: hidden;
  padding: 44px 40px;
  border-radius: 24px;
  border: 1px solid var(--line);
  background: linear-gradient(135deg, rgba(30, 40, 75, 0.88), rgba(13, 19, 36, 0.94));
  margin-bottom: 24px;
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.35);
}
.hero:after {
  content: "";
  position: absolute;
  right: -70px;
  top: -70px;
  width: 320px;
  height: 320px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(139, 92, 246, 0.38), transparent 68%);
  pointer-events: none;
}
.eyebrow {
  color: var(--teal);
  font-size: 12px;
  font-weight: 800;
  letter-spacing: 2.2px;
  text-transform: uppercase;
}
.hero h1 {
  font-family: 'Space Grotesk', sans-serif;
  font-size: clamp(32px, 4.5vw, 54px);
  line-height: 1.08;
  margin: 12px 0 10px;
  letter-spacing: -1px;
}
.hero p {
  color: var(--muted);
  font-size: 16px;
  max-width: 660px;
  line-height: 1.6;
  position: relative;
  z-index: 1;
}

/* CARDS & PANELS */
div[data-testid="stVerticalBlockBorderWrapper"] {
  background: var(--card);
  border: 1px solid var(--line) !important;
  border-radius: var(--radius) !important;
  backdrop-filter: blur(14px);
  box-shadow: 0 18px 45px rgba(0,0,0,0.25);
}
.panel-h {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 21px;
  font-weight: 700;
  margin-bottom: 4px;
}
.sub-muted {
  color: var(--muted);
  font-size: 13.5px;
  margin-bottom: 14px;
}

/* METRICS / STAT CARDS */
.stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 14px;
  margin: 16px 0 22px;
}
.stat-box {
  background: var(--card-solid);
  border: 1px solid var(--line);
  padding: 16px 20px;
  border-radius: 16px;
  position: relative;
  overflow: hidden;
}
.stat-box:before {
  content: "";
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--violet), var(--teal));
}
.stat-val {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 28px;
  font-weight: 800;
  color: #fff;
  line-height: 1.15;
}
.stat-lbl {
  font-size: 12px;
  font-weight: 600;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: 0.8px;
  margin-top: 4px;
}

/* BUTTONS */
.stButton > button {
  border: 0 !important;
  border-radius: 12px !important;
  padding: 0.65rem 1.25rem !important;
  color: #fff !important;
  font-weight: 700 !important;
  font-size: 14px !important;
  background: linear-gradient(100deg, var(--violet), var(--indigo)) !important;
  box-shadow: 0 8px 22px rgba(99, 102, 241, 0.35) !important;
  transition: all 0.16s ease !important;
}
.stButton > button:hover {
  transform: translateY(-2px) !important;
  filter: brightness(1.1) !important;
  box-shadow: 0 12px 28px rgba(99, 102, 241, 0.48) !important;
}
.stButton > button:disabled {
  background: #1c243b !important;
  color: #637194 !important;
  box-shadow: none !important;
  transform: none !important;
}

/* RADIO CARDS (QUIZ OPTIONS) */
div[data-testid="stRadio"] > div {
  gap: 10px !important;
}
div[data-testid="stRadio"] label[data-baseweb="radio"] {
  width: 100%;
  padding: 14px 18px;
  border-radius: 14px;
  background: #0d152c;
  border: 1.5px solid var(--line);
  transition: all 0.14s ease;
  margin: 0;
}
div[data-testid="stRadio"] label[data-baseweb="radio"]:hover {
  border-color: var(--violet);
  background: #141f3e;
  transform: translateX(3px);
}
div[data-testid="stRadio"] label[data-baseweb="radio"]:has(input:checked) {
  border-color: var(--teal);
  background: linear-gradient(100deg, rgba(139, 92, 246, 0.22), rgba(52, 224, 208, 0.12));
  box-shadow: 0 0 0 3px rgba(52, 224, 208, 0.15);
}

/* INPUTS & TEXTAREA */
div[data-testid="stTextInput"] input,
div[data-testid="stTextArea"] textarea {
  background: #0b1226 !important;
  color: var(--text) !important;
  border: 1px solid var(--line) !important;
  border-radius: 12px !important;
}
div[data-testid="stFileUploader"] section {
  background: #0b1226;
  border: 1.5px dashed #4b5e8c;
  border-radius: 12px;
}
div[data-baseweb="select"] > div {
  background: #0b1226 !important;
  border: 1px solid var(--line) !important;
  border-radius: 12px !important;
}

/* RESULT CIRCLE */
.result-box {
  display: flex;
  align-items: center;
  gap: 32px;
  flex-wrap: wrap;
  padding: 10px 4px;
}
.ring {
  width: 160px;
  height: 160px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: conic-gradient(var(--teal) calc(var(--p) * 1%), rgba(255, 255, 255, 0.08) 0);
  box-shadow: 0 0 34px rgba(52, 224, 208, 0.22);
}
.ring-center {
  width: 128px;
  height: 128px;
  border-radius: 50%;
  background: var(--card-solid);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.ring-center b {
  font-family: 'Space Grotesk', sans-serif;
  font-size: 36px;
  line-height: 1;
}
.ring-center span {
  font-size: 11px;
  color: var(--muted);
  margin-top: 3px;
}

/* REVIEW BOXES */
.rev-item {
  padding: 14px 18px;
  border-radius: 14px;
  margin: 10px 0;
  border: 1px solid var(--line);
  background: #0d152c;
  border-left: 5px solid var(--muted);
}
.rev-item.correct { border-left-color: var(--good); }
.rev-item.wrong { border-left-color: var(--bad); }
.rev-q { font-weight: 700; margin-bottom: 6px; font-size: 15px; }
.rev-ans { font-size: 13.5px; margin: 2px 0; }
.rev-src { font-size: 12.5px; color: var(--muted); margin-top: 6px; font-style: italic; }

/* TABS */
.stTabs [data-baseweb="tab-list"] {
  gap: 8px;
  background: rgba(255, 255, 255, 0.03);
  padding: 6px;
  border-radius: 14px;
  border: 1px solid var(--line);
}
.stTabs [data-baseweb="tab"] {
  height: 42px;
  border-radius: 10px;
  color: var(--muted);
  font-weight: 600;
  font-size: 14px;
}
.stTabs [aria-selected="true"] {
  background: linear-gradient(100deg, rgba(139, 92, 246, 0.25), rgba(91, 108, 255, 0.25)) !important;
  color: #fff !important;
  border: 1px solid var(--violet) !important;
}
</style>
""", unsafe_allow_html=True)

# ==============================================================================
# BUILT-IN CURRICULUM NOTES (FROM USER'S ATTACHED DOCUMENTS)
# ==============================================================================
COURSE_NOTES = {
    "📐 Maths, Physics & Chemistry": {
        "summary": "Core definitions, formulas, and difficulty tiers from elementary to advanced concepts.",
        "text": """
Mathematics is the study of numbers, quantities, shapes, patterns and logical relationships. It helps us calculate, measure, compare and solve problems.
Examples include adding cost of items, calculating discounts, measuring area of a room, and finding average marks.
In Mathematics, Easy level involves basic questions using simple rules such as addition, subtraction, multiplication, division, fractions, and simple shapes.
Medium level Mathematics requires combining ideas, such as percentages, ratios, averages, simple equations, area, and perimeter.
Hard level Mathematics demands deep reasoning, including quadratic equations, trigonometry, coordinate geometry, probability, and calculus.

Physics is the branch of science that studies matter, energy, motion, forces and how the universe behaves.
It explains natural phenomena like why objects fall, how a bicycle moves, how light reflects in mirrors, and how electricity powers appliances.
Easy Physics covers familiar ideas like units and measurements, states of matter, basic motion, and simple light concepts.
Medium Physics requires formulas and concept understanding, such as speed, distance, time, force, work, energy, and basic electricity.
Hard Physics involves multi-step calculations, including Newton's laws of motion, electric circuits, waves, optics calculations, and gravitation.

Chemistry is the branch of science that studies matter, what substances are made of, their properties, how they combine, and how they change during reactions.
Examples of chemistry in daily life include rust forming on iron, sugar dissolving in water, cooking food, and acid reacting with a base.
Easy Chemistry explores basic terms, states of matter, elements and compounds, symbols of common elements, and mixtures.
Medium Chemistry involves patterns and rules, like atomic structure, periodic table basics, balancing chemical equations, and acids and bases.
Hard Chemistry requires detailed reasoning, such as mole concept calculations, chemical bonding, stoichiometry, equilibrium, and organic reaction mechanisms.
"""
    },
    "💻 Programming Methodology": {
        "summary": "Systematic program development, algorithms, flowcharts, pseudocode, paradigms, and debugging.",
        "text": """
Programming Methodology is a systematic way of planning, designing, writing, testing, and maintaining computer programs.
It provides a step-by-step approach to convert complex real-world problems into executable computer instructions.
The primary objectives are to understand requirements, divide large problems into smaller modules, choose suitable data structures, and create reusable code.
Program development follows nine standard steps: Problem definition, Problem analysis, Algorithm design, Flowchart or Pseudocode, Coding, Testing, Debugging, Documentation, and Maintenance.

An algorithm is a finite sequence of clear and unambiguous steps designed to solve a problem or complete a specific task.
A good algorithm must satisfy five key characteristics: Input, Output, Definiteness, Finiteness, and Effectiveness.
Pseudocode is an informal, language-independent method of writing program logic using structured, human-readable English statements.
A flowchart is a graphical representation of an algorithm using standardized symbols connected by directional arrows.
In flowcharts, an Oval represents a Terminal point (Start or End), a Rectangle represents a Process or calculation, a Parallelogram represents Input or Output, a Diamond represents a Decision branch, and Arrows indicate flow direction.

Programming paradigms describe fundamental approaches to structuring code.
Procedural programming organizes code into linear procedures and functions executed step by step, as seen in C.
Object-oriented programming (OOP) organizes software around reusable objects encapsulating data and methods, prominent in Java, Python, and C++.
Functional programming treats computation as mathematical functions, avoiding mutable state and side effects, as found in Haskell.
Common software errors include Syntax errors (grammar rule violations), Runtime errors (crashes during execution like division by zero), and Logical errors (incorrect output caused by flawed algorithms).
Testing verifies software with normal, boundary, and unexpected inputs, whereas Debugging is the process of locating, isolating, and fixing defects.
"""
    },
    "🌐 Fundamentals of Information Technology": {
        "summary": "Hardware, operating systems, memory hierarchy, networking, and cybersecurity essentials.",
        "text": """
Information Technology (IT) is the use of computers, storage, networking, and digital devices to collect, process, secure, and exchange information.
While Information Technology focuses on implementing and managing technology infrastructure, Computer Science centers on mathematical foundations and algorithmic software design.
Data refers to raw unorganized facts such as numbers and symbols. Information is structured data processed into a meaningful format. Knowledge represents understanding gained by interpreting information.
A computer system comprises Hardware (tangible physical parts), Software (executable programs), Peopleware (operators and administrators), and Data.
The Information Processing Cycle follows the IPO model: Input, Processing, and Output, backed by persistent Storage.

Computers are classified by capability: Supercomputers handle massive scientific calculations and simulations. Mainframes manage heavy concurrent transaction processing in banking. Servers provide resources across networks. Personal computers and laptops perform everyday business and study tasks.
Input devices convert human actions into digital signals (keyboard, mouse, scanner, webcam). Output devices display processed results (monitor, printer, speakers).
System software manages computer hardware directly (operating systems and drivers), while Application software performs specific user tasks (browsers, word processors, spreadsheets).
Memory hierarchy includes primary volatile RAM for active execution, non-volatile ROM for firmware startup, high-speed Cache near the CPU, and secondary persistent storage like SSDs and hard disks.
Computer networks are categorized by geographic span: Personal Area Network (PAN), Local Area Network (LAN), Metropolitan Area Network (MAN), and Wide Area Network (WAN).
Cybersecurity protects systems, networks, and data from unauthorized exploitation, combating threats such as malware, ransomware, and phishing attacks.
"""
    },
    "🏛️ UPSC & Govt Competitive Exams": {
        "summary": "Indian Polity & Constitution, Macroeconomics, Modern History, Geography, and Governance.",
        "text": """
Constitutionalism ensures government authority is constrained by constitutional rules, fundamental rights, and institutional checks and balances.
In the landmark Kesavananda Bharati judgment of 1973, the Supreme Court ruled that Parliament cannot alter or destroy the Basic Structure of the Indian Constitution under Article 368.
The Constitution distributes legislative powers between the Union and States across three lists in the Seventh Schedule: Union List, State List, and Concurrent List.
Article 14 guarantees equality before the law and equal protection of the laws, permitting reasonable classification based on intelligible differentia with a rational nexus.
Article 19 protects fundamental freedoms including speech and assembly, subject to reasonable restrictions, while Article 21 guarantees protection of life and personal liberty.
Article 32 and Article 226 empower the Supreme Court and High Courts respectively to issue prerogative writs for the enforcement of fundamental rights.
Article 280 establishes the Finance Commission to recommend tax devolution and financial grants between the Union and States.
Article 324 vests the superintendence, direction, and control of all parliamentary and assembly elections in the Election Commission of India.

In Macroeconomics, Gross Domestic Product (GDP) measures the monetary value of all final goods and services produced within a domestic territory during a financial period.
Gross Value Added (GVA) at basic prices adjusted for net product taxes and subsidies equals GDP at market prices.
Real GDP adjusts nominal output for inflation using constant base year prices through the GDP deflator.
Fiscal deficit represents the excess of total government expenditure over total non-debt receipts. Primary deficit equals fiscal deficit minus interest payments.
Monetary policy is formulated by the Reserve Bank of India (RBI) through policy rates such as the Repo rate, Cash Reserve Ratio (CRR), and Statutory Liquidity Ratio (SLR).
In Indian Geography, the southwest monsoon is governed by differential land-sea thermal contrasts, migration of the Inter-Tropical Convergence Zone (ITCZ), the Somali Jet, and ocean-atmosphere phenomena like ENSO and the Indian Ocean Dipole.
In Science and Ecology, optical fibres transmit signals via Total Internal Reflection. In-situ conservation protects species in natural habitats, whereas Ex-situ conservation preserves biological genetic material in seed banks and botanical reserves.
"""
    }
}

# Pre-compiled authentic MCQs from user's attached notes
CURATED_MCQS = {
    "🏛️ UPSC & Govt Competitive Exams": [
        {
            "question": "Which Article of the Indian Constitution provides for the constitution of a Finance Commission?",
            "options": ["Article 263", "Article 280", "Article 324", "Article 356"],
            "answer": 1,
            "explanation": "Article 280 provides for a Finance Commission appointed by the President every five years to recommend tax sharing."
        },
        {
            "question": "A joint sitting of both Houses of Parliament under Article 108 is NOT provided for which type of Bill?",
            "options": ["Ordinary Bill", "Deadlocked legislative bill", "Money Bill", "Private Member Bill"],
            "answer": 2,
            "explanation": "Under Article 108, joint sittings cannot be convened for Money Bills (Article 110) or Constitutional Amendment Bills (Article 368)."
        },
        {
            "question": "In macroeconomics, what is Primary Deficit?",
            "options": ["Fiscal deficit + Interest payments", "Fiscal deficit − Interest payments", "Revenue deficit − Grants", "Total debt − GDP"],
            "answer": 1,
            "explanation": "Primary Deficit = Fiscal Deficit minus interest payments made on past borrowings."
        },
        {
            "question": "In which year did the Cabinet Mission arrive in India?",
            "options": ["1935", "1942", "1946", "1947"],
            "answer": 2,
            "explanation": "The Cabinet Mission arrived in India in March 1946 to discuss the transfer of power and constitutional framework."
        },
        {
            "question": "At which of the following locations is the Coriolis force zero?",
            "options": ["North and South Poles", "Equator", "Tropic of Cancer", "Arctic Circle"],
            "answer": 1,
            "explanation": "Coriolis force is directly proportional to the sine of latitude (2Ωv sin φ), making it zero at the Equator and maximum at the poles."
        },
        {
            "question": "Which of the following is an example of an ex-situ biodiversity conservation method?",
            "options": ["National Park", "Wildlife Sanctuary", "Seed Bank", "Sacred Grove"],
            "answer": 2,
            "explanation": "Seed banks, botanical gardens, and zoos preserve genetic diversity outside natural habitats (ex-situ)."
        },
        {
            "question": "Optical fibre data transmission functions primarily on which physical principle?",
            "options": ["Diffraction of light", "Total Internal Reflection", "Polarization", "Interference"],
            "answer": 1,
            "explanation": "Light signals travel through optical fibre cores by repeatedly undergoing Total Internal Reflection at angles greater than the critical angle."
        },
        {
            "question": "A social audit in public governance and administration primarily strengthens which pillar?",
            "options": ["Official Secrecy", "Community oversight and accountability", "Monetary policy", "Judicial appointments"],
            "answer": 1,
            "explanation": "Social audit is a participatory tool where citizens and beneficiaries verify official records against ground realities to enforce accountability."
        }
    ],
    "💻 Programming Methodology": [
        {
            "question": "In standard flowchart notation, which geometrical shape represents an Input or Output operation?",
            "options": ["Rectangle", "Oval", "Parallelogram", "Diamond"],
            "answer": 2,
            "explanation": "A Parallelogram indicates input from users or output display; Rectangles represent processes and Diamonds represent decisions."
        },
        {
            "question": "Which of the following is NOT one of the five mandatory characteristics of an algorithm?",
            "options": ["Finiteness", "Infinite recursion", "Definiteness", "Effectiveness"],
            "answer": 1,
            "explanation": "Algorithms must terminate after a finite number of steps (Finiteness). Infinite recursion violates this requirement."
        },
        {
            "question": "Dividing a number by zero in an executable program triggers which type of error?",
            "options": ["Syntax error", "Runtime error", "Logical error", "Grammar error"],
            "answer": 1,
            "explanation": "A division-by-zero error passes compiler syntax checks but crashes during execution, making it a Runtime error."
        },
        {
            "question": "Which testing type specifically verifies that individual functions or small units of code operate correctly?",
            "options": ["System testing", "Acceptance testing", "Unit testing", "Integration testing"],
            "answer": 2,
            "explanation": "Unit testing isolates and tests the smallest testable parts (functions, methods) of an application."
        }
    ],
    "🌐 Fundamentals of Information Technology": [
        {
            "question": "Which type of computer memory is volatile and loses its stored contents when power is turned off?",
            "options": ["ROM", "Solid State Drive (SSD)", "Random Access Memory (RAM)", "Flash memory"],
            "answer": 2,
            "explanation": "RAM is temporary working memory that requires continuous electric power to retain stored data."
        },
        {
            "question": "What is the smallest unit of digital information in computer storage?",
            "options": ["Byte", "Bit", "Nibble", "Kilobyte"],
            "answer": 1,
            "explanation": "A bit (binary digit) is the fundamental unit with a value of either 0 or 1. A byte contains 8 bits."
        },
        {
            "question": "A computer network spanning across a single city or municipal campus is called a:",
            "options": ["PAN", "LAN", "MAN", "WAN"],
            "answer": 2,
            "explanation": "A Metropolitan Area Network (MAN) covers a city or large campus area (e.g. citywide cable or municipal network)."
        },
        {
            "question": "Which malicious attack trick involves impersonating a trusted entity to steal passwords or financial credentials?",
            "options": ["Defragmentation", "Phishing", "Data compilation", "Packet routing"],
            "answer": 1,
            "explanation": "Phishing deceives victims into revealing sensitive personal data like passwords and credit card numbers."
        }
    ]
}

# ==============================================================================
# PERSISTENT LOCAL DATA STORE
# ==============================================================================
def init_data_store():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    # Default seed database
    default_store = {
        "users": {
            "student@quizforge.com": {
                "name": "Kavya Ramesh",
                "role": "student",
                "password": "123",
                "grade": "Class 12 / Competitive Aspirant"
            },
            "teacher@quizforge.com": {
                "name": "Prof. S. Arumugam",
                "role": "teacher",
                "password": "123",
                "subject": "Computer Science & Science"
            }
        },
        "published_tests": [
            {
                "id": "TEST-101",
                "code": "UPSC-MOCK",
                "title": "UPSC Civil Services Foundation — Polity & Economy",
                "subject": "🏛️ UPSC & Govt Competitive Exams",
                "teacher": "Prof. S. Arumugam",
                "difficulty": "Hard",
                "created_at": "2026-10-30 18:30",
                "questions": CURATED_MCQS["🏛️ UPSC & Govt Competitive Exams"][:5]
            },
            {
                "id": "TEST-102",
                "code": "CS-PROG",
                "title": "Programming Methodology & Algorithm Design",
                "subject": "💻 Programming Methodology",
                "teacher": "Prof. S. Arumugam",
                "difficulty": "Medium",
                "created_at": "2026-10-30 19:15",
                "questions": CURATED_MCQS["💻 Programming Methodology"]
            },
            {
                "id": "TEST-103",
                "code": "IT-101",
                "title": "Information Technology Core Concepts Test",
                "subject": "🌐 Fundamentals of Information Technology",
                "teacher": "Prof. S. Arumugam",
                "difficulty": "Easy",
                "created_at": "2026-10-30 20:00",
                "questions": CURATED_MCQS["🌐 Fundamentals of Information Technology"]
            }
        ],
        "submissions": [
            {
                "student_name": "Rahul Verma",
                "student_email": "rahul@school.edu",
                "test_id": "TEST-101",
                "test_title": "UPSC Civil Services Foundation — Polity & Economy",
                "score": 4,
                "total": 5,
                "percentage": 80,
                "date": "2026-10-30 20:45"
            },
            {
                "student_name": "Ananya Sundaram",
                "student_email": "ananya@school.edu",
                "test_id": "TEST-101",
                "test_title": "UPSC Civil Services Foundation — Polity & Economy",
                "score": 5,
                "total": 5,
                "percentage": 100,
                "date": "2026-10-30 21:10"
            },
            {
                "student_name": "Kavya Ramesh",
                "student_email": "student@quizforge.com",
                "test_id": "TEST-102",
                "test_title": "Programming Methodology & Algorithm Design",
                "score": 4,
                "total": 4,
                "percentage": 100,
                "date": "2026-10-30 22:00"
            }
        ]
    }
    save_data_store(default_store)
    return default_store

def save_data_store(data):
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        st.error(f"Failed to save data: {e}")

# ==============================================================================
# QUESTION GENERATOR LOGIC
# ==============================================================================
STOPWORDS = {
    "about", "above", "after", "again", "against", "also", "because", "been",
    "before", "being", "below", "between", "both", "could", "does", "doing",
    "during", "each", "either", "every", "from", "further", "have", "having",
    "here", "into", "itself", "make", "makes", "many", "might", "more", "most",
    "much", "must", "never", "other", "others", "over", "same", "should",
    "since", "some", "such", "than", "that", "their", "them", "then", "there",
    "these", "they", "this", "those", "through", "under", "until", "upon",
    "using", "used", "very", "were", "what", "when", "where", "which", "while",
    "will", "with", "within", "without", "would", "your", "usually", "often",
    "called", "known", "generally", "mainly", "example", "include", "includes", "including"
}

def read_pdf_text(file):
    try:
        from pypdf import PdfReader
        reader = PdfReader(file)
        text = "\n".join((page.extract_text() or "") for page in reader.pages)
        return re.sub(r"(?<![.!?:;])\n(?!\n)", " ", text)
    except Exception:
        return None

def get_sentences(text):
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    sentences, seen = [], set()
    for part in parts:
        part = re.sub(r"\s+", " ", part).strip(" -•*\t")
        if 6 <= len(part.split()) <= 45 and part.lower() not in seen:
            seen.add(part.lower())
            sentences.append(part)
    return sentences

def get_keywords(sentence):
    words = re.findall(r"[A-Za-z]+(?:[-'][A-Za-z]+)*", sentence)
    return [w for w in words if len(w) >= 5 and w.lower() not in STOPWORDS]

def build_questions(notes, count=5, difficulty="Medium"):
    sentences = get_sentences(notes)
    if not sentences:
        return []

    freq = Counter()
    for s in sentences:
        for w in get_keywords(s):
            freq[w.lower()] += 1
    pool = list(freq)
    if len(pool) < 4:
        return []

    random.shuffle(sentences)
    questions = []
    for s in sentences:
        if len(questions) >= count:
            break
        keys = list(dict.fromkeys(w.lower() for w in get_keywords(s)))
        if not keys:
            continue

        if difficulty == "Easy":
            answer = max(keys, key=lambda w: freq[w])
        elif difficulty == "Hard":
            answer = max(keys, key=len)
        else:
            answer = random.choice(keys)

        others = [w for w in pool if w[:4] != answer[:4]]
        random.shuffle(others)
        if difficulty == "Hard":
            others.sort(key=lambda w: abs(len(w) - len(answer)))

        distractors, stems = [], {answer[:4]}
        for w in others:
            if w[:4] not in stems:
                stems.add(w[:4])
                distractors.append(w)
            if len(distractors) == 3:
                break
        if len(distractors) < 3:
            continue

        blanked = re.sub(r"\b" + re.escape(answer) + r"\b", "_______", s, flags=re.IGNORECASE)
        if blanked == s:
            continue

        options = [answer] + distractors
        if blanked.strip().startswith("_______"):
            options = [o.capitalize() for o in options]
        random.shuffle(options)
        correct_text = answer.capitalize() if blanked.strip().startswith("_______") else answer

        try:
            ans_index = options.index(correct_text)
        except ValueError:
            ans_index = 0

        questions.append({
            "question": f"Fill in the blank: {blanked}",
            "options": options,
            "answer": ans_index,
            "explanation": f'Source: "{s}"'
        })
    return questions

# ==============================================================================
# SESSION STATE MANAGEMENT
# ==============================================================================
data = init_data_store()

SESSION_DEFAULTS = {
    "auth_user": None,          # {"email", "name", "role", "grade/subject"}
    "active_nav": "Home",       # Home, Student, Teacher, Guest
    "active_quiz": None,        # dict of questions, metadata
    "quiz_in_progress": False,
    "quiz_completed": False,
    "current_q_idx": 0,
    "user_answers": {},
    "last_result": None
}

for k, v in SESSION_DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ==============================================================================
# TOP NAVIGATION BAR
# ==============================================================================
def render_navbar():
    u = st.session_state.auth_user
    col_l, col_r = st.columns([1.5, 1])
    with col_l:
        st.markdown("""
        <div class="brand-group">
          <div class="brand-logo">✦</div>
          <div>
            <div class="brand-title">QuizForge <span class="grad-text">AI</span></div>
            <div style="font-size:11px; color:#95a3c6; letter-spacing:1px; margin-top:-3px;">ADAPTIVE LEARNING & TEST CREATOR PORTAL</div>
          </div>
        </div>
        """, unsafe_allow_html=True)
    with col_r:
        if u:
            role_cls = f"badge-{u['role']}"
            st.markdown(f"""
            <div style="display:flex; justify-content:flex-end; align-items:center; gap:12px;">
              <div class="user-pill">
                <span>👤 <b>{u['name']}</b></span>
                <span class="role-badge {role_cls}">{u['role']}</span>
              </div>
            </div>
            """, unsafe_allow_html=True)
            if st.button("Logout", key="btn_logout", use_container_width=False):
                st.session_state.auth_user = None
                st.session_state.quiz_in_progress = False
                st.session_state.quiz_completed = False
                st.session_state.active_nav = "Home"
                st.rerun()
        else:
            st.markdown("""
            <div style="display:flex; justify-content:flex-end; align-items:center; gap:8px;">
              <span class="role-badge badge-guest">Guest Mode</span>
            </div>
            """, unsafe_allow_html=True)

render_navbar()

# ==============================================================================
# PRE-LOGIN LANDING PAGE ("PRESOLOGIN")
# ==============================================================================
if not st.session_state.auth_user:
    # Sub-nav tabs
    nav_tabs = ["✦ Home & Features", "👨‍🎓 Student Portal", "👩‍🏫 Teacher Studio", "⚡ Quick Guest Test"]
    current_tab = st.radio("Portal Navigation", nav_tabs, horizontal=True, label_visibility="collapsed")

    # --- TAB 1: HOME & FEATURES ---
    if current_tab == "✦ Home & Features":
        st.markdown("""
        <div class="hero">
          <div class="eyebrow">NEXT-GEN EDUCATION & ASSESSMENT</div>
          <h1>Transform Study Notes into<br><span class="grad-text">Interactive Mock Tests.</span></h1>
          <p>The comprehensive test creation & revision platform for schools, colleges, and competitive exams.
          Generate high-yield questions from PDFs or notes, track student mastery, and practice with real-time feedback.</p>
        </div>
        """, unsafe_allow_html=True)

        # 3 Pillar feature cards
        c1, c2, c3 = st.columns(3)
        with c1:
            with st.container(border=True):
                st.markdown("""
                <div style="font-size:28px; margin-bottom:8px;">👨‍🎓</div>
                <div class="panel-h">Student Portal</div>
                <p class="sub-muted">Take chapter practice tests, attempt teacher-assigned mock tests, review mistakes with direct source citations, and track improvement streaks.</p>
                """, unsafe_allow_html=True)
                if st.button("Open Student Login →", use_container_width=True, key="btn_go_student"):
                    st.session_state.active_nav = "Student"
                    st.rerun()

        with c2:
            with st.container(border=True):
                st.markdown("""
                <div style="font-size:28px; margin-bottom:8px;">👩‍🏫</div>
                <div class="panel-h">Teacher Studio</div>
                <p class="sub-muted">Upload course PDFs or syllabus notes, generate editable questions, publish tests with class codes, and monitor the live student gradebook.</p>
                """, unsafe_allow_html=True)
                if st.button("Open Teacher Login →", use_container_width=True, key="btn_go_teacher"):
                    st.session_state.active_nav = "Teacher"
                    st.rerun()

        with c3:
            with st.container(border=True):
                st.markdown("""
                <div style="font-size:28px; margin-bottom:8px;">⚡</div>
                <div class="panel-h">Direct Test Drive</div>
                <p class="sub-muted">No account needed. Try out the test generator instantly with our pre-loaded study topics (Maths, Physics, CS, UPSC) or your own notes.</p>
                """, unsafe_allow_html=True)
                if st.button("Try Sample Test Now →", use_container_width=True, key="btn_go_guest"):
                    st.session_state.active_nav = "Guest"
                    st.rerun()

        st.markdown("<br>", unsafe_allow_html=True)
        with st.container(border=True):
            st.markdown('<div class="panel-h">📚 Pre-Loaded Curriculums Available</div>', unsafe_allow_html=True)
            cols = st.columns(4)
            for i, (title, meta) in enumerate(COURSE_NOTES.items()):
                with cols[i]:
                    st.markdown(f"**{title}**")
                    st.caption(meta["summary"])

    # --- TAB 2: STUDENT LOGIN & REGISTRATION ---
    elif current_tab == "👨‍🎓 Student Portal":
        col_m1, col_center, col_m2 = st.columns([0.6, 2.2, 0.6])
        with col_center:
            with st.container(border=True):
                st.markdown('<div class="panel-h">👨‍🎓 Student Access Portal</div>'
                            '<p class="sub-muted">Sign in to take assigned tests, practice chapter notes, and track your scores.</p>',
                            unsafe_allow_html=True)

                # 1-Click Demo Button for instant testing
                st.info("💡 **Quick Test?** Click below to log in immediately as Demo Student.")
                if st.button("⚡ 1-Click Login as Demo Student (Kavya)", use_container_width=True, key="demo_student_btn"):
                    st.session_state.auth_user = {
                        "email": "student@quizforge.com",
                        "name": "Kavya Ramesh",
                        "role": "student",
                        "grade": "Class 12 / Competitive Aspirant"
                    }
                    st.rerun()

                st.markdown("---")
                auth_tab = st.tabs(["Sign In", "Register New Student"])
                with auth_tab[0]:
                    s_email = st.text_input("Student Email", value="student@quizforge.com", key="s_login_email")
                    s_pass = st.text_input("Password", type="password", value="123", key="s_login_pass")
                    if st.button("Sign In to Student Dashboard", use_container_width=True, key="btn_s_submit"):
                        user_record = data["users"].get(s_email)
                        if user_record and user_record.get("password") == s_pass and user_record.get("role") == "student":
                            st.session_state.auth_user = {
                                "email": s_email,
                                "name": user_record["name"],
                                "role": "student",
                                "grade": user_record.get("grade", "Student")
                            }
                            st.success(f"Welcome back, {user_record['name']}!")
                            st.rerun()
                        else:
                            st.error("Invalid student credentials. Try the 1-Click Demo Login above!")

                with auth_tab[1]:
                    r_name = st.text_input("Full Name", placeholder="e.g. Ramesh Kumar", key="r_s_name")
                    r_email = st.text_input("Email Address", placeholder="ramesh@example.com", key="r_s_email")
                    r_grade = st.selectbox("Class / Goal", ["Class 10", "Class 11", "Class 12", "UG College", "UPSC / Govt Exams"], key="r_s_grade")
                    r_pass = st.text_input("Choose Password", type="password", key="r_s_pass")
                    if st.button("Create Student Account", use_container_width=True, key="btn_r_s_submit"):
                        if r_name and r_email and r_pass:
                            data["users"][r_email] = {
                                "name": r_name,
                                "role": "student",
                                "password": r_pass,
                                "grade": r_grade
                            }
                            save_data_store(data)
                            st.session_state.auth_user = {
                                "email": r_email,
                                "name": r_name,
                                "role": "student",
                                "grade": r_grade
                            }
                            st.success("Account created successfully! Redirecting...")
                            st.rerun()
                        else:
                            st.warning("Please fill in all fields.")

    # --- TAB 3: TEACHER LOGIN & REGISTRATION ---
    elif current_tab == "👩‍🏫 Teacher Studio":
        col_m1, col_center, col_m2 = st.columns([0.6, 2.2, 0.6])
        with col_center:
            with st.container(border=True):
                st.markdown('<div class="panel-h">👩‍🏫 Teacher / Instructor Studio</div>'
                            '<p class="sub-muted">Create exams from notes/PDFs, edit question banks, and monitor student performance.</p>',
                            unsafe_allow_html=True)

                st.info("💡 **Quick Test?** Click below to log in immediately as Demo Teacher.")
                if st.button("⚡ 1-Click Login as Demo Teacher (Prof. Arumugam)", use_container_width=True, key="demo_teacher_btn"):
                    st.session_state.auth_user = {
                        "email": "teacher@quizforge.com",
                        "name": "Prof. S. Arumugam",
                        "role": "teacher",
                        "subject": "Computer Science & Science"
                    }
                    st.rerun()

                st.markdown("---")
                t_auth_tab = st.tabs(["Teacher Sign In", "Register New Teacher"])
                with t_auth_tab[0]:
                    t_email = st.text_input("Teacher Email", value="teacher@quizforge.com", key="t_login_email")
                    t_pass = st.text_input("Password", type="password", value="123", key="t_login_pass")
                    if st.button("Sign In to Teacher Studio", use_container_width=True, key="btn_t_submit"):
                        user_record = data["users"].get(t_email)
                        if user_record and user_record.get("password") == t_pass and user_record.get("role") == "teacher":
                            st.session_state.auth_user = {
                                "email": t_email,
                                "name": user_record["name"],
                                "role": "teacher",
                                "subject": user_record.get("subject", "Instructor")
                            }
                            st.success(f"Welcome back, {user_record['name']}!")
                            st.rerun()
                        else:
                            st.error("Invalid teacher credentials. Try the 1-Click Demo Login above!")

                with t_auth_tab[1]:
                    tr_name = st.text_input("Full Name & Title", placeholder="e.g. Dr. Priya Sundar", key="tr_name")
                    tr_email = st.text_input("Email Address", placeholder="priya@school.edu", key="tr_email")
                    tr_subj = st.text_input("Department / Subject", placeholder="e.g. Physics & Mathematics", key="tr_subj")
                    tr_pass = st.text_input("Choose Password", type="password", key="tr_pass")
                    if st.button("Register Teacher Account", use_container_width=True, key="btn_tr_submit"):
                        if tr_name and tr_email and tr_pass:
                            data["users"][tr_email] = {
                                "name": tr_name,
                                "role": "teacher",
                                "password": tr_pass,
                                "subject": tr_subj
                            }
                            save_data_store(data)
                            st.session_state.auth_user = {
                                "email": tr_email,
                                "name": tr_name,
                                "role": "teacher",
                                "subject": tr_subj
                            }
                            st.success("Teacher account created! Redirecting...")
                            st.rerun()
                        else:
                            st.warning("Please fill in all fields.")

    # --- TAB 4: QUICK GUEST TEST ---
    elif current_tab == "⚡ Quick Guest Test":
        st.markdown('<div class="panel-h">⚡ Quick Practice Test (Guest Mode)</div>'
                    '<p class="sub-muted">Generate a mock test directly from any study notes without logging in.</p>',
                    unsafe_allow_html=True)
        col_g1, col_g2 = st.columns([2, 1], gap="large")
        with col_g1:
            with st.container(border=True):
                topic_choice = st.selectbox("Select Study Topic", list(COURSE_NOTES.keys()) + ["📝 Paste My Own Notes / Upload PDF"])
                if topic_choice.startswith("📝"):
                    notes_content = st.text_area("Your Notes", height=200, placeholder="Paste your study notes here...")
                    uploaded = st.file_uploader("Or upload PDF/TXT", type=["pdf", "txt"], key="guest_pdf")
                    if uploaded:
                        if uploaded.name.endswith(".txt"):
                            notes_content = uploaded.getvalue().decode("utf-8", errors="ignore")
                        else:
                            notes_content = read_pdf_text(uploaded) or ""
                else:
                    notes_content = COURSE_NOTES[topic_choice]["text"]
                    st.info(f"Loaded: **{topic_choice}** ({len(notes_content.split())} words)")

                c_cnt, c_diff = st.columns(2)
                with c_cnt:
                    q_num = st.slider("Questions", 3, 10, 5, key="guest_slider")
                with c_diff:
                    q_diff = st.selectbox("Difficulty", ["Easy", "Medium", "Hard"], index=1, key="guest_diff")

                if st.button("✦ Start Guest Quiz", use_container_width=True, key="guest_start_btn"):
                    curated = CURATED_MCQS.get(topic_choice, [])
                    if curated and len(curated) >= q_num:
                        selected_qs = random.sample(curated, q_num)
                    else:
                        selected_qs = build_questions(notes_content, q_num, q_diff)

                    if not selected_qs:
                        st.warning("Could not generate enough questions. Try using more detailed notes.")
                    else:
                        st.session_state.active_quiz = {
                            "title": topic_choice,
                            "questions": selected_qs,
                            "test_id": "GUEST-TEST"
                        }
                        st.session_state.quiz_in_progress = True
                        st.session_state.quiz_completed = False
                        st.session_state.current_q_idx = 0
                        st.session_state.user_answers = {}
                        st.rerun()

        with col_g2:
            with st.container(border=True):
                st.markdown("#### ✨ Why QuizForge AI?")
                st.markdown("""
                - **100% Offline Generation**: No costly external API tokens required.
                - **Sentence-Derived Distractors**: Distractors are matched to syllabus vocabulary.
                - **Line Explanations**: Review every answer with direct textbook context.
                - **Role Dashboards**: Dedicated views for Students & Teachers.
                """)

# ==============================================================================
# LOGGED IN: STUDENT DASHBOARD
# ==============================================================================
elif st.session_state.auth_user["role"] == "student":
    user = st.session_state.auth_user

    # If currently taking a quiz:
    if st.session_state.quiz_in_progress and st.session_state.active_quiz:
        quiz = st.session_state.active_quiz
        questions = quiz["questions"]
        q_idx = st.session_state.current_q_idx
        total_q = len(questions)

        if not st.session_state.quiz_completed:
            q = questions[q_idx]
            _, mid, _ = st.columns([0.2, 3.6, 0.2])
            with mid:
                with st.container(border=True):
                    st.markdown(f"""
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                      <span style="color:var(--teal); font-weight:800; font-size:13px; letter-spacing:1.5px;">
                        {quiz['title'].upper()} · QUESTION {q_idx + 1} OF {total_q}
                      </span>
                      <span style="color:var(--muted); font-size:13px;">
                        {int((q_idx + 1)/total_q * 100)}% Completed
                      </span>
                    </div>
                    """, unsafe_allow_html=True)

                    st.progress((q_idx + 1) / total_q)
                    st.markdown(f'<div class="panel-h" style="font-size:22px; margin:20px 0;">{q["question"]}</div>', unsafe_allow_html=True)

                    current_selection = st.session_state.user_answers.get(q_idx)
                    choice = st.radio(
                        "Answer Choice",
                        options=list(range(len(q["options"]))),
                        format_func=lambda x: f"{'ABCD'[x]}.  {q['options'][x]}",
                        index=current_selection if current_selection is not None else None,
                        key=f"sq_{q_idx}",
                        label_visibility="collapsed"
                    )

                    c_prev, c_next = st.columns(2)
                    with c_prev:
                        if st.button("← Previous Question", disabled=(q_idx == 0), use_container_width=True):
                            if choice is not None:
                                st.session_state.user_answers[q_idx] = choice
                            st.session_state.current_q_idx -= 1
                            st.rerun()

                    with c_next:
                        btn_lbl = "Finish & Submit Exam ✓" if q_idx == total_q - 1 else "Next Question →"
                        if st.button(btn_lbl, use_container_width=True):
                            if choice is None:
                                st.warning("Please pick an option to continue.")
                            else:
                                st.session_state.user_answers[q_idx] = choice
                                if q_idx == total_q - 1:
                                    st.session_state.quiz_completed = True
                                    # Calculate score and save submission
                                    score = sum(1 for i, q_item in enumerate(questions) if st.session_state.user_answers.get(i) == q_item["answer"])
                                    pct = round((score / total_q) * 100)
                                    submission = {
                                        "student_name": user["name"],
                                        "student_email": user["email"],
                                        "test_id": quiz.get("test_id", "PRACTICE"),
                                        "test_title": quiz["title"],
                                        "score": score,
                                        "total": total_q,
                                        "percentage": pct,
                                        "date": datetime.now().strftime("%Y-%m-%d %H:%M")
                                    }
                                    data["submissions"].append(submission)
                                    save_data_store(data)
                                else:
                                    st.session_state.current_q_idx += 1
                                st.rerun()

        # QUIZ RESULTS SCREEN
        else:
            questions = quiz["questions"]
            total_q = len(questions)
            score = sum(1 for i, q_item in enumerate(questions) if st.session_state.user_answers.get(i) == q_item["answer"])
            wrong = total_q - score
            pct = round((score / total_q) * 100)

            with st.container(border=True):
                st.markdown(f"""
                <div class="result-box">
                  <div class="ring" style="--p:{pct}">
                    <div class="ring-center">
                      <b>{score}/{total_q}</b>
                      <span>{pct}% SCORE</span>
                    </div>
                  </div>
                  <div>
                    <div class="eyebrow">TEST COMPLETED</div>
                    <div class="panel-h" style="font-size:32px; margin:4px 0;">
                      {"Outstanding Performance! 🌟" if pct >= 80 else ("Well Done! Keep Practising 💪" if pct >= 50 else "Revision Recommended 📖")}
                    </div>
                    <div style="color:var(--muted); font-size:14px;">
                      You answered {score} out of {total_q} questions accurately in <b>{quiz['title']}</b>.
                    </div>
                    <div style="display:flex; gap:12px; margin-top:14px;">
                      <div style="background:rgba(46,229,157,0.1); border:1px solid rgba(46,229,157,0.3); padding:10px 18px; border-radius:12px;">
                        <b style="color:var(--good); font-size:20px;">{score}</b> <span style="font-size:12px; color:var(--muted);">Correct</span>
                      </div>
                      <div style="background:rgba(255,93,115,0.1); border:1px solid rgba(255,93,115,0.3); padding:10px 18px; border-radius:12px;">
                        <b style="color:var(--bad); font-size:20px;">{wrong}</b> <span style="font-size:12px; color:var(--muted);">Incorrect</span>
                      </div>
                      <div style="background:rgba(91,108,255,0.1); border:1px solid rgba(91,108,255,0.3); padding:10px 18px; border-radius:12px;">
                        <b style="color:#a5b4fc; font-size:20px;">{pct}%</b> <span style="font-size:12px; color:var(--muted);">Accuracy</span>
                      </div>
                    </div>
                  </div>
                </div>
                """, unsafe_allow_html=True)

            with st.container(border=True):
                st.markdown('<div class="panel-h">Detailed Answer Key & Source Analysis</div>', unsafe_allow_html=True)
                for i, q in enumerate(questions):
                    ans_given = st.session_state.user_answers.get(i)
                    is_correct = (ans_given == q["answer"])
                    ans_text = q["options"][ans_given] if ans_given is not None else "Not Answered"
                    correct_text = q["options"][q["answer"]]

                    cls = "correct" if is_correct else "wrong"
                    icon = "✓ Correct" if is_correct else "✗ Incorrect"
                    tag_col = "var(--good)" if is_correct else "var(--bad)"

                    st.markdown(f"""
                    <div class="rev-item {cls}">
                      <div class="rev-q">Q{i+1}. {q['question']}</div>
                      <div class="rev-ans">Your Answer: <b>{ans_text}</b></div>
                      <div class="rev-ans">Correct Answer: <b style="color:var(--teal)">{correct_text}</b></div>
                      <div style="font-weight:700; color:{tag_col}; font-size:13px; margin-top:4px;">{icon}</div>
                      <div class="rev-src">{q.get('explanation', '')}</div>
                    </div>
                    """, unsafe_allow_html=True)

                if st.button("Return to Student Dashboard", use_container_width=True):
                    st.session_state.quiz_in_progress = False
                    st.session_state.quiz_completed = False
                    st.session_state.active_quiz = None
                    st.rerun()

    # STUDENT MAIN DASHBOARD
    else:
        # Calculate student stats
        my_subs = [s for s in data["submissions"] if s["student_email"] == user["email"]]
        tests_taken = len(my_subs)
        avg_score = round(sum(s["percentage"] for s in my_subs) / tests_taken) if tests_taken > 0 else 0
        best_score = max((s["percentage"] for s in my_subs), default=0)

        st.markdown(f"""
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <div>
            <h2 style="font-family:'Space Grotesk',sans-serif; margin:0;">Welcome, {user['name']} 👋</h2>
            <div style="color:var(--muted); font-size:14px;">{user.get('grade', 'Class 12')} · Student Learning Workspace</div>
          </div>
        </div>
        """, unsafe_allow_html=True)

        # Metric stats cards
        st.markdown(f"""
        <div class="stat-grid">
          <div class="stat-box">
            <div class="stat-val">{tests_taken}</div>
            <div class="stat-lbl">Tests Completed</div>
          </div>
          <div class="stat-box">
            <div class="stat-val">{avg_score}%</div>
            <div class="stat-lbl">Average Score</div>
          </div>
          <div class="stat-box">
            <div class="stat-val">{best_score}%</div>
            <div class="stat-lbl">High Score</div>
          </div>
          <div class="stat-box">
            <div class="stat-val">5 Days 🔥</div>
            <div class="stat-lbl">Revision Streak</div>
          </div>
        </div>
        """, unsafe_allow_html=True)

        s_tabs = st.tabs(["🎯 Take a Test", "📋 Teacher Assigned Tests", "📈 My History & Review"])

        # TAB 1: PRACTICE TESTS
        with s_tabs[0]:
            col_t1, col_t2 = st.columns([2, 1], gap="large")
            with col_t1:
                with st.container(border=True):
                    st.markdown('<div class="panel-h">Launch a Practice Test</div>'
                                '<p class="sub-muted">Select a subject curriculum or input your own notes/PDF to forge a custom test.</p>',
                                unsafe_allow_html=True)

                    topic = st.selectbox("Choose Syllabus Subject", list(COURSE_NOTES.keys()) + ["📝 Paste Custom Notes / Upload PDF"])

                    if topic.startswith("📝"):
                        notes_body = st.text_area("Paste Notes Here", height=180, placeholder="Paste chapter notes or definitions...")
                        pdf_up = st.file_uploader("Upload Notes (.pdf or .txt)", type=["pdf", "txt"], key="s_pdf_up")
                        if pdf_up:
                            if pdf_up.name.endswith(".txt"):
                                notes_body = pdf_up.getvalue().decode("utf-8", errors="ignore")
                            else:
                                notes_body = read_pdf_text(pdf_up) or ""
                    else:
                        notes_body = COURSE_NOTES[topic]["text"]
                        st.info(f"Loaded syllabus notes for **{topic}**.")

                    col_s1, col_s2 = st.columns(2)
                    with col_s1:
                        num_qs = st.slider("Question Count", 3, 10, 5, key="s_q_count")
                    with col_s2:
                        diff = st.selectbox("Target Difficulty", ["Easy", "Medium", "Hard"], index=1, key="s_diff")

                    if st.button("✦ Start Practice Test", use_container_width=True, key="btn_start_s_quiz"):
                        curated = CURATED_MCQS.get(topic, [])
                        if curated and len(curated) >= num_qs:
                            picked_qs = random.sample(curated, num_qs)
                        else:
                            picked_qs = build_questions(notes_body, num_qs, diff)

                        if not picked_qs:
                            st.warning("Could not generate enough questions. Try using longer notes with more complete sentences.")
                        else:
                            st.session_state.active_quiz = {
                                "title": topic,
                                "questions": picked_qs,
                                "test_id": "PRACTICE"
                            }
                            st.session_state.quiz_in_progress = True
                            st.session_state.quiz_completed = False
                            st.session_state.current_q_idx = 0
                            st.session_state.user_answers = {}
                            st.rerun()

            with col_t2:
                with st.container(border=True):
                    st.markdown('<div class="panel-h">💡 Study Guidelines</div>', unsafe_allow_html=True)
                    st.markdown("""
                    - **Easy**: Focus on definitions, core terms, and direct vocabulary.
                    - **Medium**: Multi-concept statements, processes, and applications.
                    - **Hard**: Deep reasoning, multi-step formulations, and exam questions.
                    - **Review Screen**: Always examine incorrect answers to inspect the source sentence.
                    """)

        # TAB 2: TEACHER ASSIGNED TESTS
        with s_tabs[1]:
            with st.container(border=True):
                st.markdown('<div class="panel-h">📋 Exams Published by Teachers</div>'
                            '<p class="sub-muted">Active tests created by your school or institution instructors.</p>',
                            unsafe_allow_html=True)

                tests = data.get("published_tests", [])
                if not tests:
                    st.info("No published tests available at this time.")
                else:
                    for t in tests:
                        col_info, col_btn = st.columns([3, 1])
                        with col_info:
                            st.markdown(f"**{t['title']}** — `{t['code']}`")
                            st.caption(f"Created by: {t['teacher']} · Subject: {t['subject']} · Difficulty: {t['difficulty']} · Questions: {len(t['questions'])}")
                        with col_btn:
                            if st.button("Start Exam →", key=f"btn_pub_{t['id']}", use_container_width=True):
                                st.session_state.active_quiz = {
                                    "title": t["title"],
                                    "questions": t["questions"],
                                    "test_id": t["id"]
                                }
                                st.session_state.quiz_in_progress = True
                                st.session_state.quiz_completed = False
                                st.session_state.current_q_idx = 0
                                st.session_state.user_answers = {}
                                st.rerun()
                        st.markdown("<hr style='margin:10px 0; border-color:var(--line);'>", unsafe_allow_html=True)

        # TAB 3: HISTORY & ANALYTICS
        with s_tabs[2]:
            with st.container(border=True):
                st.markdown('<div class="panel-h">📈 Your Past Performance History</div>', unsafe_allow_html=True)
                if not my_subs:
                    st.info("You haven't completed any tests yet. Take a practice test above!")
                else:
                    for sub in reversed(my_subs):
                        pct_color = "var(--good)" if sub["percentage"] >= 80 else ("var(--amber)" if sub["percentage"] >= 50 else "var(--bad)")
                        st.markdown(f"""
                        <div style="display:flex; justify-content:space-between; align-items:center; padding:12px 16px; border-radius:12px; background:rgba(255,255,255,0.03); border:1px solid var(--line); margin-bottom:8px;">
                          <div>
                            <div style="font-weight:700; font-size:15px;">{sub['test_title']}</div>
                            <div style="font-size:12px; color:var(--muted);">{sub['date']} · Score: {sub['score']}/{sub['total']}</div>
                          </div>
                          <div style="font-size:22px; font-weight:800; font-family:'Space Grotesk',sans-serif; color:{pct_color};">
                            {sub['percentage']}%
                          </div>
                        </div>
                        """, unsafe_allow_html=True)

# ==============================================================================
# LOGGED IN: TEACHER DASHBOARD
# ==============================================================================
elif st.session_state.auth_user["role"] == "teacher":
    user = st.session_state.auth_user

    # Teacher metrics
    my_tests = data.get("published_tests", [])
    all_subs = data.get("submissions", [])
    avg_class = round(sum(s["percentage"] for s in all_subs) / len(all_subs)) if all_subs else 0

    st.markdown(f"""
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
      <div>
        <h2 style="font-family:'Space Grotesk',sans-serif; margin:0;">Teacher Studio: {user['name']} 👩‍🏫</h2>
        <div style="color:var(--muted); font-size:14px;">{user.get('subject', 'Faculty')} · Exam Creator & Class Analytics</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    # Metric Cards
    st.markdown(f"""
    <div class="stat-grid">
      <div class="stat-box">
        <div class="stat-val">{len(my_tests)}</div>
        <div class="stat-lbl">Active Tests</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">{len(all_subs)}</div>
        <div class="stat-lbl">Student Submissions</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">{avg_class}%</div>
        <div class="stat-lbl">Class Average</div>
      </div>
      <div class="stat-box">
        <div class="stat-val">92%</div>
        <div class="stat-lbl">Passing Rate</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    t_tabs = st.tabs(["🛠️ Quiz Creator Studio", "📋 Class Gradebook & Submissions", "📚 Published Tests Manager"])

    # TAB 1: QUIZ CREATOR STUDIO
    with t_tabs[0]:
        st.markdown('<div class="panel-h">Create & Publish a New Test</div>'
                    '<p class="sub-muted">Generate draft questions from your syllabus, edit question wording and options, then publish directly to students.</p>',
                    unsafe_allow_html=True)

        col_left, col_right = st.columns([1.8, 1.2], gap="large")
        with col_left:
            with st.container(border=True):
                st.markdown("#### Step 1: Syllabus & Test Details")
                t_title = st.text_input("Test Title", placeholder="e.g. Unit 3 — Information Technology & Networks", key="t_new_title")
                t_code = st.text_input("Course / Exam Code", placeholder="e.g. IT-NET-202", key="t_new_code")
                t_subj = st.selectbox("Target Curriculum", list(COURSE_NOTES.keys()) + ["📝 Custom Notes / Upload Syllabus PDF"], key="t_new_subj")

                if t_subj.startswith("📝"):
                    t_notes = st.text_area("Paste Syllabus Notes", height=160, placeholder="Paste chapter content or notes...")
                    t_pdf = st.file_uploader("Upload Syllabus PDF", type=["pdf", "txt"], key="t_pdf_upload")
                    if t_pdf:
                        if t_pdf.name.endswith(".txt"):
                            t_notes = t_pdf.getvalue().decode("utf-8", errors="ignore")
                        else:
                            t_notes = read_pdf_text(t_pdf) or ""
                else:
                    t_notes = COURSE_NOTES[t_subj]["text"]
                    st.info(f"Using pre-loaded curriculum: **{t_subj}**")

                c1, c2 = st.columns(2)
                with c1:
                    t_q_count = st.slider("Number of Questions", 3, 10, 5, key="t_q_count")
                with c2:
                    t_diff = st.selectbox("Difficulty Level", ["Easy", "Medium", "Hard"], index=1, key="t_diff")

                if st.button("✦ Generate Draft Questions", use_container_width=True, key="btn_gen_draft"):
                    curated = CURATED_MCQS.get(t_subj, [])
                    if curated and len(curated) >= t_q_count:
                        draft_qs = random.sample(curated, t_q_count)
                    else:
                        draft_qs = build_questions(t_notes, t_q_count, t_diff)

                    if draft_qs:
                        st.session_state["draft_questions"] = draft_qs
                        st.success(f"Generated {len(draft_qs)} draft questions! You can review or edit them on the right.")
                    else:
                        st.error("Could not generate questions. Please ensure notes contain full sentences.")

        with col_right:
            with st.container(border=True):
                st.markdown("#### Step 2: Interactive Question Editor")
                draft_qs = st.session_state.get("draft_questions", [])

                if not draft_qs:
                    st.info("Click **'Generate Draft Questions'** to preview and customize question prompts and options here.")
                else:
                    st.markdown(f"**Reviewing {len(draft_qs)} Questions:**")
                    edited_qs = []
                    for i, q_item in enumerate(draft_qs):
                        with st.expander(f"Question {i+1}: {q_item['question'][:45]}...", expanded=(i == 0)):
                            new_prompt = st.text_area(f"Q{i+1} Prompt", value=q_item["question"], key=f"q_edit_prompt_{i}", height=75)
                            opt_cols = st.columns(2)
                            new_opts = []
                            for j in range(len(q_item["options"])):
                                with opt_cols[j % 2]:
                                    val = st.text_input(f"Option {'ABCD'[j]}", value=q_item["options"][j], key=f"q_edit_opt_{i}_{j}")
                                    new_opts.append(val)
                            new_ans = st.selectbox(f"Correct Answer", [0, 1, 2, 3], index=q_item["answer"], format_func=lambda x: f"Option {'ABCD'[x]}", key=f"q_edit_ans_{i}")
                            new_exp = st.text_input(f"Explanation / Citation", value=q_item.get("explanation", ""), key=f"q_edit_exp_{i}")
                            edited_qs.append({
                                "question": new_prompt,
                                "options": new_opts,
                                "answer": new_ans,
                                "explanation": new_exp
                            })

                    if st.button("🚀 Publish Test to Students", use_container_width=True, key="btn_publish_test"):
                        if not t_title or not t_code:
                            st.warning("Please provide a Test Title and Course Code before publishing.")
                        else:
                            new_test = {
                                "id": f"TEST-{random.randint(1000, 9999)}",
                                "code": t_code,
                                "title": t_title,
                                "subject": t_subj,
                                "teacher": user["name"],
                                "difficulty": t_diff,
                                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                                "questions": edited_qs
                            }
                            data["published_tests"].append(new_test)
                            save_data_store(data)
                            st.success(f"🎉 Test '{t_title}' [{t_code}] published successfully! It is now accessible on all student dashboards.")
                            st.session_state["draft_questions"] = []
                            st.rerun()

    # TAB 2: CLASS GRADEBOOK
    with t_tabs[1]:
        with st.container(border=True):
            st.markdown('<div class="panel-h">📋 Student Submissions & Gradebook</div>'
                        '<p class="sub-muted">Live view of student scores, accuracy, and test submission timestamps.</p>',
                        unsafe_allow_html=True)

            if not all_subs:
                st.info("No student submissions yet.")
            else:
                for sub in reversed(all_subs):
                    sc_col = "var(--good)" if sub["percentage"] >= 80 else ("var(--amber)" if sub["percentage"] >= 50 else "var(--bad)")
                    st.markdown(f"""
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:12px 18px; border-radius:12px; background:rgba(255,255,255,0.03); border:1px solid var(--line); margin-bottom:8px;">
                      <div>
                        <div style="font-weight:700; font-size:15px; color:#fff;">👤 {sub['student_name']} <span style="font-size:12px; color:var(--muted);">({sub['student_email']})</span></div>
                        <div style="font-size:13px; color:#c5d1ed; margin-top:2px;">Test: <b>{sub['test_title']}</b></div>
                        <div style="font-size:11.5px; color:var(--muted);">{sub['date']}</div>
                      </div>
                      <div style="text-align:right;">
                        <div style="font-size:22px; font-weight:800; font-family:'Space Grotesk',sans-serif; color:{sc_col};">
                          {sub['percentage']}%
                        </div>
                        <div style="font-size:12px; color:var(--muted);">{sub['score']} / {sub['total']} Marks</div>
                      </div>
                    </div>
                    """, unsafe_allow_html=True)

    # TAB 3: PUBLISHED TESTS MANAGER
    with t_tabs[2]:
        with st.container(border=True):
            st.markdown('<div class="panel-h">📚 Manage Published Tests</div>', unsafe_allow_html=True)
            for idx_t, p_test in enumerate(my_tests):
                with st.expander(f"📌 {p_test['code']}: {p_test['title']} ({len(p_test['questions'])} Questions)"):
                    st.markdown(f"**Subject:** {p_test['subject']} | **Difficulty:** {p_test['difficulty']} | **Published:** {p_test['created_at']}")
                    for qi, q in enumerate(p_test["questions"]):
                        st.markdown(f"**Q{qi+1}. {q['question']}**")
                        for oi, opt in enumerate(q["options"]):
                            check = " ✅" if oi == q["answer"] else ""
                            st.caption(f"- {'ABCD'[oi]}. {opt}{check}")

# FOOTER
st.markdown("<br><hr style='border-color:var(--line);'>", unsafe_allow_html=True)
st.markdown("<div style='text-align:center; color:#7888ad; font-size:12.5px;'>QuizForge AI · Complete EdTech Platform for Students & Educators · Fully Local & Private</div>", unsafe_allow_html=True)
