# QuizForge AI — Multi-Role EdTech & Mock Test Platform ✦

A full-stack, local & cloud-ready adaptive quiz generation and exam management platform built with Python & Streamlit.

## 🌟 Key Features

1. **Pre-Login Showcase ("PRESOLOGIN")**:
   - Modern landing page with interactive features overview and curriculum preview.
   - **4 Pre-loaded Study Curriculums**:
     - 📐 *Maths, Physics & Chemistry*
     - 💻 *Programming Methodology & Algorithms*
     - 🌐 *Fundamentals of Information Technology*
     - 🏛️ *UPSC & Central/State Competitive Examinations*
   - Direct guest test-drive without registration.

2. **👨‍🎓 Student Portal**:
   - Practice Arena with auto-generated questions from PDF/notes.
   - Attempt tests published by teachers using Class/Course Codes.
   - Instant visual score gauge (radial progress ring) & performance analytics.
   - Detailed review mode with line-by-line source citations.
   - Comprehensive test history and revision streak tracking.

3. **👩‍🏫 Teacher Studio (Instructor Dashboard)**:
   - **Quiz Creator Studio**: Auto-generate questions from syllabus PDFs/notes.
   - **Interactive Question Editor**: Customize questions, option choices, correct answers, and citations before publishing.
   - **Publish to Class**: Assign Test Title, Course Code, and Difficulty.
   - **Live Class Gradebook**: Track all student attempts, scores, percentages, and timestamps in real time.
   - **Test Bank Manager**: View and manage all active exams.

---

## ⚡ Quick Demo Accounts

- **Demo Student**:
  - Email: `student@quizforge.com`
  - Password: `123`
  - *(Or click the `⚡ 1-Click Login as Demo Student` button in the UI)*

- **Demo Teacher**:
  - Email: `teacher@quizforge.com`
  - Password: `123`
  - *(Or click the `⚡ 1-Click Login as Demo Teacher` button in the UI)*

---

## 🚀 How to Run

### Option 1: 1-Click Windows Launcher
Double click:
```
run_app.bat
```

### Option 2: Terminal Command
```powershell
cd "C:\Users\NEXT GEN\.gemini\antigravity\scratch\quizforge-ai"
python -m streamlit run quizforge_app.py --server.address 0.0.0.0 --server.port 8501
```

---

## 🌐 Public Sharing & Cloud Deployment

### 1. Instant Tunnel (Localtunnel):
```bash
npx localtunnel --port 8501
```

### 2. Permanent 24/7 Hosting (Streamlit Community Cloud):
1. Push this folder to a GitHub repository.
2. Visit [share.streamlit.io](https://share.streamlit.io).
3. Connect your GitHub repository and select `quizforge_app.py`.
4. Your application will be live at `https://<your-app-name>.streamlit.app` permanently for free.
